# -*- coding: utf-8 -*-

import xbmcaddon,os,requests,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,random,xbmcaddon,socket
import time,logging
import threading,StringIO,gzip
import datetime,json,cookielib
from collections import namedtuple
import cloudflare,HTMLParser
import StorageServer

__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
__USERAGENTSDAROT__ = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36'
__BASENICKJADD__= 'http://nickjr.walla.co.il/'
__BASE_URL_NICK__ = 'http://nick.walla.co.il/'
__settings__ = xbmcaddon.Addon(id='plugin.video.Ebs4_Kids_Tv')
__language__ = __settings__.getLocalizedString
__PLUGIN_PATH__ = __settings__.getAddonInfo('path')
addonName = __settings__.getAddonInfo("name")
__LOG_FILE_LOC='special://logpath/'
__debuging__="NO_DEBUG_MODE"
__cachePeriod__ = __settings__.getSetting("cache")
DOMAIN='https://www.sdarot.live'
__REFERER__ = DOMAIN+'/templates/frontend/blue_html5/player/jwplayer.flash.swf'
__DEBUG__ = __settings__.getSetting("DEBUG") == "true"
#__LOG_FILE_LOCATION=__LOG_FILE_LOC.getAddonInfo('path')
HOST = DOMAIN[8:]
addonIcon = __settings__.getAddonInfo('icon')
path = xbmc.translatePath(__settings__.getAddonInfo("profile"))
cookie_path = os.path.join(path, 'sdarot-cookiejar.txt')
#print("Loading cookies from :" + repr(cookie_path))
Domain = __settings__.getSetting("domain")
baseUrl = Domain[:-1] if Domain.endswith('/') else Domain
ok_for_nick=['http://nick.walla.co.il/?w=//1688133','http://nick.walla.co.il/?w=//2886393','http://nick.walla.co.il/?w=//1699202','http://nick.walla.co.il/?w=//1778310','http://nick.walla.co.il/?w=//2516297','http://nick.walla.co.il/?w=//1688270','http://nick.walla.co.il/?w=//2961528','http://nick.walla.co.il/?w=//2788103','http://nick.walla.co.il/?w=//1699175','http://nick.walla.co.il/?w=//1849206','http://nick.walla.co.il/?w=//2689720','http://nick.walla.co.il/?w=//2923088','http://nick.walla.co.il/?w=//2891310','http://nick.walla.co.il/?w=//2579878','http://nick.walla.co.il/?w=//2853389','http://nick.walla.co.il/?w=//1888143','http://nick.walla.co.il/?w=//2802800','http://nick.walla.co.il/?w=//1699180','http://nick.walla.co.il/?w=//2594836']
cookiejar = cookielib.LWPCookieJar(cookie_path)
cache = StorageServer.StorageServer("Nick_Series_List", 24) # (Your plugin name, Cache time in hours)
if os.path.exists(cookie_path):
	try:
		cookiejar.load()
	except:
		pass
elif not os.path.exists(path):
	os.makedirs(path) 
	
cookie_handler = urllib2.HTTPCookieProcessor(cookiejar)
opener = urllib2.build_opener(cookie_handler)
urllib2.install_opener(opener)

user_dataDir = xbmc.translatePath(__settings__.getAddonInfo("profile")).decode("utf-8")
if not os.path.exists(user_dataDir):
     os.makedirs(user_dataDir)
images_file = os.path.join(user_dataDir, 'images_file_nick_EBS.txt')
if not (os.path.isfile(images_file)):
	f = open(images_file, 'w') 
	f.write('{}') 
	f.close() 

__addonname__ = __settings__.getAddonInfo('name')
__icon__ = __settings__.getAddonInfo('icon')
def clean(contentType, name):
        
    try:
         
        if isinstance(name, str):
         
            if contentType.lower().find('utf-8') == -1: 
            
                name = name.decode('windows-1255', 'replace')
                name = name.encode('utf-8')
        elif isinstance(name, unicode):
            name = name.encode('utf-8')    
 
    except Exception as e:
         print 'Error in clean: '
         print e
         raise e
#     if (name):
#         cleanName = name.replace("&quot;", "\"").replace("&#39;", "'").replace("&nbsp;", " ")
#         return  cleanName
    return name

def clean_cache():
	try:
		if os.path.isfile(cookie_path):
			os.unlink(cookie_path)
	except Exception as ex:
		xbmc.log(str(ex), 3)
	tempDir = xbmc.translatePath('special://temp/').decode("utf-8")
	for the_file in os.listdir(tempDir):
		if not '.fi' in the_file and the_file != 'cookies.dat':
			continue
		file_path = os.path.join(tempDir, the_file)
		try:
			if os.path.isfile(file_path):
				os.unlink(file_path)
		except Exception as ex:
			xbmc.log(str(ex), 3)
	



def CATEGORIES():
 addDir3("ניק גוניור",'http://nickjr.walla.co.il/',2,__PLUGIN_PATH__ + "\\resources\\nickjr.jpg",__PLUGIN_PATH__ + "\\resources\\nickjr.jpg","","0")
 addDir3("ניקולדיאן",__BASE_URL_NICK__,17,__PLUGIN_PATH__ + "\\resources\\nick.jpg",__PLUGIN_PATH__ + "\\resources\\nick.jpg","","0")
 addDir3("רשימות השמעה",'http://youtube.com/',6,__PLUGIN_PATH__ + "\\resources\\list.jpg",__PLUGIN_PATH__ + "\\resources\\list.jpg","","0")
 addDir3("תוכניות לקטנטנים",'http://youtube.com/',19,__PLUGIN_PATH__ + "\\resources\\baby_tv_show.jpg",__PLUGIN_PATH__ + "\\resources\\baby_tv_show.jpg","","0")
 addDir3("טריילרים",'http://youtube.com/',9,__PLUGIN_PATH__ + "\\resources\\trailer.png",__PLUGIN_PATH__ + "\\resources\\trailer.png","","0")

 addDir3("מאתר סדרות",'http://nickjr.walla.co.il/',10,__PLUGIN_PATH__ + "\\resources\\sdarot.png",__PLUGIN_PATH__ + "\\resources\\sdarot.png","","1")
 addDir3("הרחבות סרטים",'http://youtube.com/',16,__PLUGIN_PATH__ + "\\resources\\movies.jpg",__PLUGIN_PATH__ + "\\resources\\movies.jpg","","0")

 
 
 addDir3("מצב טלויזיה",'http://nickjr.walla.co.il/',5,__PLUGIN_PATH__ + "\\resources\\tv.jpg",__PLUGIN_PATH__ + "\\resources\\tv.jpg","","1")
 addDir3("טלויזיה לקטנטנים",'http://nickjr.walla.co.il/',20,__PLUGIN_PATH__ + "\\resources\\baby_tv.jpg",__PLUGIN_PATH__ + "\\resources\\baby_tv.jpg","","1")
 addDir2('[COLOR blue]Clean chache - ניקוי מטמון[/COLOR]','http://nickjr.walla.co.il/',14,__PLUGIN_PATH__ + "\\resources\\clean.png",__PLUGIN_PATH__ + "\\resources\\tv.jpg","","1")
 #listnames=[]
 
 #r = requests.get('http://reshet.tv/general/programs/')

 #match = re.compile('"post_name":"(.+?)","ID":(.+?),"title":"(.+?)","link":"(.+?)","target":null,"images":{"app_feed":"(.+?)"').findall(r.content)
 #match =re.compile('"post_name":"(.+?)","ID":(.+?),"title":"(.+?)","link":"(.+?)","target":(.+?),"images":{"app_feed":"(.+?)"').findall(r.content)
 #for name,id,title,link,target,image in match:
 #    addDir3(title.decode('unicode_escape').encode('utf-8'),link.replace('\\/', '/'),3,image.replace('\\/', '/'),image.replace('\\/', '/'),title.decode('unicode_escape').encode('utf-8'),listnames,)
def Movies_Addson():
  if not os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.movixws'):
   downloader_is('https://github.com/kodil/kodil/raw/master/repo/plugin.video.movixws/plugin.video.movixws-1.2.9.zip?raw=true','Movix') 
  else:
   addDirkids('MOVIX ','plugin://plugin.video.movixws/?mode=2&name=Dubbed - מדובבים&url=http://movix.me/search_movies?q=%D7%9E%D7%93%D7%95%D7%91%D7%91&sb=&year=',15,'http://www.afaqs.com/all/news/images/news_story_grfx/2015/45297_1_home_big.jpg','')

  if not os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.jksp'):
   downloader_is('https://github.com/Jksp/jksp.repo/raw/master/repository/zips/plugin.video.jksp/plugin.video.jksp-0.0.7.zip?raw=true','Jksp')
  else:
   addDirkids('סרטי ילדים מJksp ','plugin://plugin.video.jksp',15,'https://github.com/Jksp/jksp.repo/raw/master/repository/zips/plugin.video.jksp/fanart.jpg','')
  
  if not os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.wallaNew.video'):
   downloader_is('https://github.com/cubicle-vdo/xbmc-israel/raw/master/repo/plugin.video.wallaNew.video/plugin.video.wallaNew.video-2.2.5.zip?raw=true','walla')
  else: 
   addDirkids('וואלה ילדים','plugin://plugin.video.wallaNew.video/?mode=1&module=wallavod&name=י%d7%99%d7%9c%d7%93%d7%99%d7%9d&url=englishName%3dkids',15,'https://lh6.ggpht.com/V8v_FzkTMqeLRg_oY7G00zf0bcxubsm659cLrbf9nEKMLHQG-5LSZdbbJGQgkV6j1PQ=w300','')
    
  if not os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.seretil'):
   downloader_is('https://github.com/kodil/kodil/raw/master/repo/plugin.video.seretil/plugin.video.seretil-2.2.8.zip?raw=true','seretil')
  else: 
   addDirkids('SeretIL','plugin://plugin.video.seretil/?mode=4&name=מדובבים&url=http://hinami.me/category/%D7%A1%D7%A8%D7%98%D7%99%D7%9D-%D7%9E%D7%93%D7%95%D7%91%D7%91%D7%99%D7%9D/',15,'http://www.in-hebrew.co.il/images/logo-s.jpg','')
 
 
def update_view(url):

    ok=True        
    xbmc.executebuiltin('XBMC.Container.Update(%s)' % url )
    return ok
def addDirkids(name,url,mode,iconimage,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description} )
        menu = []
        

        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
        return ok
      

		
def downloader_is (url,name ) :
 import downloader,extract   
 i1iIIII = xbmc . getInfoLabel ( "System.ProfileName" )
 I1 = xbmc . translatePath ( os . path . join ( 'special://home' , '' ) )
 O0OoOoo00o = xbmcgui . Dialog ( )
 if name.find('repo')< 0 :
     choice = O0OoOoo00o . yesno ( "XBMC ISRAEL" , "לחץ כן להתקנת תוסף חסר" ,name)
 else:
     choice=True
 if    choice :
  iiI1iIiI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
  iiiI11 = xbmcgui . DialogProgress ( )
  iiiI11 . create ( "XBMC ISRAEL" , "Downloading " , '' , 'Please Wait' )
  OOooO = os . path . join ( iiI1iIiI , 'isr.zip' )
  try :
     os . remove ( OOooO )
  except :
      pass
  downloader . download ( url , OOooO , iiiI11 )
  II111iiii = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
  iiiI11 . update ( 0 , "" , "Extracting Zip Please Wait" )
  print '======================================='
  print II111iiii
  print '======================================='
  extract . all ( OOooO , II111iiii , iiiI11 )
  iiiI11 . update ( 0 , "" , "Downloading" )
  iiiI11 . update ( 0 , "" , "Extracting Zip Please Wait" )
  xbmc . executebuiltin ( 'UpdateLocalAddons ' )
  xbmc . executebuiltin ( "UpdateAddonRepos" )
  if 96 - 96: i1IIi . ii1IiI1i * iiiIIii1I1Ii % i111I
  if 60 - 60: iII11iiIII111 * IIIiiIIii % IIIiiIIii % O00oOoOoO0o0O * i11i + i1IIi
##################################################NICKOLIAN##############################################
def GetlistMatch():
    images=ReadList(images_file)
    list=[]
    contentType,block = getMatches(__BASE_URL_NICK__,'padding: 10px(.*?)folder2_game')
    page = re.compile('<a href="(.*?)".*?">(.*?)<').findall(block[0])
    
    for path in page:
                
                summary = ''
                iconImage=''
                url=__BASE_URL_NICK__ + path[0]
                if not url in images:
                       iconImage=getImageNick(url)
                       images[url]=iconImage
                iconImage=images[url]
                title=path[1]
                list.append((clean(contentType,title),__BASE_URL_NICK__ + path[0],iconImage))
                
    return list
def getSeriesList(tv_mode):
            list2=[]
            names=[]

            images=ReadList(images_file)
            matches_list=cache.cacheFunction(GetlistMatch)
            for items in matches_list:
               list2.append(items[1])
               names.append(items[0])
               if tv_mode=="0":
                 addDir3(items[0], items[1], 18, items[2], items[2], '',"0")
            if tv_mode=="0":
             
             WriteList(images_file, images)
             xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
            if tv_mode=="1":
             show=random.choice(list2)
             count_for_break=0
             
             while show not in ok_for_nick:
              
                show=random.choice(list2)
                count_for_break=count_for_break+1
                if count_for_break>100:
                 if __debuging__=="DEBUG_MODE":
                   logging.warning("EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE")
                 return None
             
             xbmcgui.Dialog().notification('Tv', "מוסיף לרשימה:" + names[list2.index(show)], xbmcgui.NOTIFICATION_INFO,1000 )
             show2= getEpisodeList_Nick(show,"1")
             
             return show2,names[list2.index(show)] 
def ReadList(fileName):
	try:
		with open(fileName, 'r') as handle:
			content = json.load(handle)
	except Exception as ex:
		print ex
		content=[]
	return content
def getImageNick(url):
            contentType,page = getData(url)
            titleMatches = re.compile('class="stripe_title w7b white">\s*(.*?)\s*</h1>\s*<img src="(.*?)"').findall(page)
            if len(titleMatches) == 0:
                # try a different possibility
                titleMatches = re.compile('class="stripe_title w7b white">.*?>(.*?)<.*?src="(.*?)"').findall(page)
            if titleMatches:
                    #urllib.urlretrieve(titleMatches[0][1], cachePath)
                   return titleMatches[0][1]
            return ''
def WriteList(filename, list):
	try:
		with io.open(filename, 'w', encoding='utf-8') as handle:
			handle.write(unicode(json.dumps(list, indent=2, ensure_ascii=False)))
		success = True
	except Exception as ex:
		print ex
		success = False
		
	return success

def getEpisodeList_Nick( inUrl,tv_mode):
  list=[]
  list_name=[]
  mode=2
  patternFeatured='<div class="title w5b mt5"><a href="(.*?)"'
  modulename='nick'
  pattern='<div class="title w3b"><a href="(.*?)"'
  urlbase=__BASE_URL_NICK__
  patternmore='class="in_blk p_r"\sstyle=""\shref="(.*?)"'
  nextPage_number=10
  current_page=1
  counter_break=0

  while nextPage_number > current_page:

	current_page=nextPage_number
	
	contentType, more = getData(inUrl)
	urls = re.compile('<a class=" left w2b more_btn_01" href="(.+?)"').findall(more)
	if len(urls)>0:

	 inUrl=urlbase+urls[0]

	if '2836047' in inUrl:
		 getEpisodeList(urlbase,'http://nickjr.walla.co.il/?w=//2775381',pattern, modulename, mode, patternFeatured='', patternmore='class="in_blk p_r"\sstyle=""\shref="(.*?)"')
	if '2968570' in inUrl:
		 getEpisodeList(urlbase,'http://nickjr.walla.co.il/?w=//2775381',pattern, modulename, mode, patternFeatured='', patternmore='class="in_blk p_r"\sstyle=""\shref="(.*?)"')
	contentType,mainPage = getData(inUrl)
	if 'nick' in urlbase and  not 'page' in inUrl:
		#urlMatch = re.compile('class="w6b.?.*?href="(.*?)">').findall(mainPage)
		block=re.compile('show_nav oflow w3 bgclr1(.*?)content_holder').findall(mainPage)
		para=re.compile('a href="(.*?)".*?click="(.*?)"').findall(block[0])
		urlMatch=''
		print ';;;;' + str( urlMatch)
		if (len(urlMatch)) > 0:
		  inUrl=urlbase+urlMatch
		  contentType,mainPage = getData(inUrl)
	#Episode = namedtuple('Episode', ['content', 'title', 'url', 'iconImage', 'time', 'epiDetails'])    
	
	#cacheKey = modulename + "_" + inUrl + "_episodes"
	#episodes = cacheServer.get(cacheKey)


	if False:
		episodes = eval(episodes)
		print "Found " + str(len(episodes)) + " episodes in cache"

		for episode in episodes:
			list.append(episode.url)
			list_name.append(episode.title)
			addLink(episode.content, episode.title, episode.url, episode.iconImage, episode.time, episode.epiDetails)
			   
	else:
		#episodes = []
		
		# # get all the rest of the episodes
		contentType, mainPage = getData(inUrl)
		if patternFeatured != '':
			urls = re.compile(patternFeatured).findall(mainPage)
			urls += re.compile(pattern).findall(mainPage)
		else:
			urls = re.compile(pattern).findall(mainPage)
			urls += re.compile('<div class="title w5b mt5"><a href="(.*?)"').findall(mainPage)
		# # for each episode we get the episode page to parse all the info from
		
		
		for path in urls:
			
			if urlbase in path:
			 contentType, page = getData(path + '/@@/video/flv_pl')

			else:
			 contentType, page = getData(urlbase + path + '/@@/video/flv_pl')

			titleMatches = re.compile('<title>(.*?)</title>(.*)<subtitle>(.*?)<').findall(page)
			if (len(titleMatches)) == 1:
				title = titleMatches[0][0]

				images = re.compile('<preview_pic>(.*?)</preview_pic>').findall(page)
				if (len(images)) >= 1:
					iconImage = images[0]
				details = re.compile('<synopsis>(.*?)</synopsis>').findall(page)
				if (len(details)) > 0:
					epiDetails = details[0]
				
				timeInSeconds = re.compile('<duration>(.*?)</duration>').findall(page)
				if not timeInSeconds == None and not len(timeInSeconds[0]) <= 0:
					time = int(timeInSeconds[0]) / 60
				else:
					time = '00:00'

				url='http://62.90.90.56/walla_vod/_definst_/'+ re.compile('<src>(.*?)</src>').findall(page)[0]+'.mp4/playlist.m3u8'
				#epi1 = Episode(content=contentType, title=title, url=url, iconImage=iconImage, time=str(time), epiDetails=epiDetails)
				#episodes.append(epi1)
				list.append(url)
				list_name.append(title)
				if tv_mode=="0":
				 addLink(contentType, title, url, iconImage, str(time), epiDetails)
			
		
		# save to cache
		#cacheServer.set(cacheKey, repr(episodes))
	
	counter_break=counter_break+1
	if counter_break>9:
	 if __debuging__=="DEBUG_MODE":
	  logging.warning("KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK")
	  logging.warning(url)
	 return None
	nextPage = re.compile(patternmore).findall(mainPage)
	if len(nextPage)==0:
	 break
	inUrl=urlbase + nextPage[0]

	nextPage_number=nextPage[0][-1:]

  if tv_mode=="1":
       if len(list)>0:
         show=random.choice(list)
         name_fix=clean(contentType,list_name[list.index(show)])
         listitem =xbmcgui.ListItem (name_fix)
         
         listitem.setInfo('video', {'Title': name_fix, 'Genre': 'Kids'})
         if __debuging__=="DEBUG_MODE":
          logging.warning("Player_Start_Now")
         return show
       else:
        return None
  else:
   xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
 
	#if (len(nextPage)) > 0:
	#	addDir('UTF-8', __language__(30001), urlbase + nextPage[0], mode, 'DefaultFolder.png', modulename)


  

##################################################SDAROT_TV##############################################
def Sdarot_Tv(url,page,tv_mode):
	
	if page == 'no':
		page = 'https://www.sdarot.live/ajax/series?loadMore=9999&start=1&search%5Bfrom%5D=&search%5Bto%5D=&search%5Border%5D=&search%5Bdir%5D='
	else:
		page = 'https://www.sdarot.live/ajax/series?loadMore=9999&start=1&search%5Bgenre%5D%5B%5D={0}&search%5Bfrom%5D=&search%5Bto%5D=&search%5Border%5D=&search%5Bdir%5D='.format(38)
	page = getData(page)

	matches = re.compile('<img.*?src="(.*?)".*?<h4>(.*?)</h4>.*?<h5>(.*?)</h5>.*?href="(.*?)"', re.S).findall(page[1])
	sr_arr = []
	for match in matches:
	  heb_name = HTMLParser.HTMLParser().unescape(match[1].decode("utf-8")).strip()
	  eng_name = HTMLParser.HTMLParser().unescape(match[2].decode("utf-8")).strip()
	  if url == "all-eng":
		sr_arr.append(( match[0], match[3], eng_name ))
	  else:
		sr_arr.append(( match[0], match[3], heb_name ))
	sr_sorted = sorted(sr_arr,key=lambda sr_arr: sr_arr[2])
	list=[]
	for key in sr_sorted:
	  series_link = DOMAIN + str(key[1])
	  image_link = 'https:' + str(key[0])
	  series_id = image_link[image_link.rfind('/')+1:image_link.rfind('.')]
	  if tv_mode=="1":

	    
	    list.append((series_link,str(series_id),urllib.quote(key[2].encode("utf-8")),urllib.quote(image_link),key[2]))
	  else:
	    
	    #addDir_Sdarot(key[2],series_link,"11&image="+urllib.quote(image_link)+"&series_id="+str(key[0])+"&series_name="+urllib.quote(key[2].encode("utf-8")),image_link)
	    addDir_Sdarot(key[2],series_link,"11&image="+urllib.quote(image_link)+"&series_id="+series_id+"&series_name="+urllib.quote(key[2].encode("utf-8")),image_link)
	if tv_mode=="1":
	  temp=random.choice(list)
	  
	  x=0
	  f =read_txt_files('https://raw.githubusercontent.com/ebs111/ebs_repo/master/band.txt')
	  
	  #logging.warning("file:")
	  #logging.warning(f)
	  #logging.warning(temp[1])
	  #temp=("418","418","418","418")
	  while urllib.quote("מדובב") not in temp[2] and temp[1] not in f:
	    x=x+1
	    if x>100:
	     break
	    temp=random.choice(list)

	  temp2=sdarot_series(temp[0],temp,"1")
	  #logging.warning("New 2")
	  #logging.warning(temp[4])
	  #logging.warning("Number:" )
	  #temp3=str(temp[4])
	  xbmcgui.Dialog().notification('Tv', "מוסיף לרשימה:" + temp[4].encode("utf-8"), xbmcgui.NOTIFICATION_INFO,1000 )
	  return temp2,temp[4].encode("utf-8")
	  
	  
	xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
	xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
 
 
def getData_Sdarot(url, timeout=__cachePeriod__, name='', postData=None,referer=__REFERER__):
		for i in range(3):
		  #print "getData: Attempt " + str(i)
		  try:
			return getData_attempt(url, timeout, name, postData,referer)
		  except urllib2.URLError, e:
			print e
			if (i == 2):
			  raise e
			  

def getData_attempt(url, timeout=__cachePeriod__, name='', postData=None,referer=__REFERER__):
		#print 'getData: url --> ' + url + '\npostData-->' + str(postData)
		if __DEBUG__:
			print 'name --> ' + name
		#temporary disabled the cache - cause problems with headers	
		if timeout > 9999999:
			if name == '':
				cachePath = xbmc.translatePath(os.path.join(__PLUGIN_PATH__, 'cache', 'pages', urllib.quote(url,"")))
			else:
				cachePath = xbmc.translatePath(os.path.join(__PLUGIN_PATH__, 'cache', 'pages', name))
			if (os.path.exists(cachePath) and (time.time()-os.path.getmtime(cachePath))/60/60 <= float(timeout)):
				f = open(cachePath, 'r')
				ret = f.read()
				f.close()
				if __DEBUG__:
					print 'returned data from cache'
				return ret
		socket.setdefaulttimeout(15)
		req = urllib2.Request(url)
		req.add_header('User-Agent', __USERAGENT__)   
		req.add_header('X-Requested-With','XMLHttpRequest')
		req.add_header('Accept','application/json, text/javascript, */*; q=0.01')
		req.add_header('Accept-Encoding','gzip,deflate,sdch')
		req.add_header('Content-Type','application/x-www-form-urlencoded; charset=UTF-8')
		req.add_header('Connection','keep-alive')
		req.add_header('Host',HOST)
		req.add_header('Origin',DOMAIN)
		if (postData):
			req.add_header('Content-Length',len(postData))
		
		if referer: 
			req.add_header ('Referer',referer)
			
		if __DEBUG__:
			print "sent headers:" + str(req.headers)           
#		response = urllib2.urlopen(url=req,timeout=180,data=postData)
		response = cloudflare.ddos_open(url=req,timeout=180,data=postData)

		if __DEBUG__:
			print "received headers:" + str(response.info());
		
		if response.info().get('Content-Encoding') == 'gzip':
			buf = StringIO.StringIO( response.read())
			f = gzip.GzipFile(fileobj=buf)
			data = f.read()
			#print "received gzip len " + str(len(data))
		   
		else:
			data = response.read()

		if data:
			data = data.replace("\n","").replace("\t","").replace("\r","")   
					 
		try:
			#print sys.modules["__main__"].cookiejar
			sys.modules["__main__"].cookiejar.save()
			
		except Exception,e:
			print e	   
		
		if __DEBUG__:
			print "recieved data:" + str(data)
					   
		response.close()
		
		try:
			if timeout > 999999:
				f = open(cachePath, 'wb')
				f.write(data)
				f.close()
			if __DEBUG__:
				print data
			return data
		except:
			return data
def addDir_Sdarot(name, url, mode, iconimage='DefaultFolder.png', elementId=None, summary='', fanart='',contextMenu=None, isFolder=True):
		fanart=iconimage
		u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + name+ "&summary=" + urllib.quote_plus(summary)
		if not elementId == None and not elementId == '':
			u += "&module=" + urllib.quote_plus(elementId)
		liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
		liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote(name), "Plot": UnEscapeXML(urllib.unquote(summary))})
		
		if not contextMenu == None:
			liz.addContextMenuItems(items=contextMenu, replaceItems=False)

		if not fanart == '':
			liz.setProperty("Fanart_Image", fanart)
		ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder)
		return ok
def UnEscapeXML(str):
	return str.replace('&amp;', '&').replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", '"').replace("&#39;", "'").replace("&#039;", "'")
def sdarot_series(url,link,tv_mode):
	list=[]
	if tv_mode=="0":
	  series_id=urllib.unquote_plus(params["series_id"])
	  series_name=urllib.unquote_plus(params["series_name"])
	  image_link=urllib.unquote_plus(params["image"])
	else:
	  series_id=link[1]
	  series_name=link[2]
	  image_link=link[3]
	#opener.addheaders = [('Referer',url)]
	#opener.open(DOMAIN+'/landing/'+series_id).read()
  #  print "sdarot_series: Fetching URL:"+url  
	try:
		page = getData_Sdarot(url,referer=DOMAIN+'/series')
		#page = opener.open(url).read()
		#print cookiejar
	except urllib2.URLError, e:
		print 'sdarot_season: got http error ' +str(e.code) + ' fetching ' + url + "\n"
		raise e
	#page = getData(url);
	#print "Page Follows:\n"
	#print page
				 #<ul id="season">
	matches = re.compile('תקציר הסדרה.*?<p>(.*?)</p>', re.S).findall(page)
	summary = matches[0] if len(matches) == 1 else ""
	seasons_list = re.compile('id="season">(.*?)</ul>',re.S).findall(page)[0]
	matches = re.compile('>(\d+)</a').findall(seasons_list)
			
	for season in matches:
		list.append((url,str(series_id),urllib.quote(series_name),str(season),urllib.quote(image_link)))
		if tv_mode=="0":
		   addDir_Sdarot("עונה "+ str(season),url,"12&image="+urllib.quote(image_link)+"&season_id="+str(season)+"&series_id="+str(series_id)+"&series_name="+urllib.quote(series_name),image_link,summary=summary)
		   

	if tv_mode=="1":
	 temp=random.choice(list)
	 temp2=sdarot_season(temp[0],temp,"1")

	 return(temp2)
	xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	xbmc.executebuiltin('Container.SetViewMode(504)')
	#xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')

	  
def sdarot_season(url, link,tv_mode):
	list=[]
	if tv_mode=="0":
	  series_id=urllib.unquote_plus(params["series_id"])
	  series_name=urllib.unquote_plus(params["series_name"])
	  season_id=urllib.unquote_plus(params["season_id"])
	  image_link=urllib.unquote_plus(params["image"])
	else:
	  series_id=link[1]
	  series_name=link[2]
	  season_id=link[3]
	  image_link=link[4]
	page = getData_Sdarot(url=DOMAIN+"/ajax/watch?episodeList="+series_id+"&season="+season_id,timeout=0,referer=url);
	episodes = re.compile('<li data-episode="(.*?)"').findall(page)
	if episodes is None or (len(episodes)==0):
		if tv_mode=="0":
		  xbmcgui.Dialog().ok('Error occurred',"לא נמצאו פרקים לעונה")
		return
	
	#print episodes
	for epis in episodes :
		
		
		list.append((url,str(series_id),urllib.quote(series_name),str(season_id),urllib.quote(image_link),epis))
		if (tv_mode=="0"):
		   addVideoLink("פרק "+epis, url, "13&episode_id="+epis+"&image="+urllib.quote(image_link)+"&season_id="+str(season_id)+"&series_id="+str(series_id)+"&series_name="+urllib.quote(series_name),image_link, summary)		 
		   
	
	if tv_mode=="1":
	 temp=random.choice(list)
	 temp2=sdarot_movie(temp[0],"",temp,None,"1")

	 return(temp2)
	else:
	  xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	  xbmc.executebuiltin('Container.SetViewMode(504)')
		

def addVideoLink(name, url, mode, iconimage='DefaultFolder.png', summary = '', contextMenu=True):
		fanart=iconimage
		u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + "&summary=" + urllib.quote_plus(summary)
		liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
		liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote(name), "Plot": UnEscapeXML(urllib.unquote(summary))})	
		liz.setProperty('IsPlayable', 'true')
		liz.setProperty("Fanart_Image", fanart)
		if contextMenu:
			liz.addContextMenuItems(items=[(__language__(30005).encode('utf-8'), 'XBMC.Container.Update({0})'.format(u.replace('mode=4', 'mode=8')))])
		ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
		return ok
	
def sdarot_movie(url, summary,link, m_quality,tv_mode):
	referer=url
	if tv_mode=="0":
	
	  series_id=urllib.unquote_plus(params["series_id"])
	  series_name=urllib.unquote_plus(params["series_name"])
	  season_id=urllib.unquote_plus(params["season_id"])
	  image_link=urllib.unquote_plus(params["image"])
	  episode_id=urllib.unquote_plus(params["episode_id"])
	else:
	  series_id=link[1]
	  series_name=link[2]
	  season_id=link[3]
	  image_link=link[4]
	  episode_id=link[5]
	title = series_name + ", עונה " + season_id + ", פרק " + episode_id
	i = url.rfind('/')
	url = '{0}-{1}/season/{2}/episode/{3}'.format(url[:i], urllib.quote(url[i+1:]), season_id, episode_id)

	finalUrl, VID = getFinalVideoUrl(series_id, season_id, episode_id, url,tv_mode, m_quality=m_quality)
	page = getData_Sdarot(url=DOMAIN+"/ajax/watch",timeout=1,postData="count="+VID,referer=referer)
	if tv_mode=="1":

	 return finalUrl

	liz = xbmcgui.ListItem(path=finalUrl)
	liz.setInfo(type="Video", infoLabels={ "Title": title, "Plot": urllib.unquote(summary) })	
	liz.setProperty('IsPlayable', 'true')
	xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=liz)
	ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=finalUrl, listitem=liz, isFolder=False)
	
def getFinalVideoUrl(series_id,season_id,episode_id,referer,tv_mode,silent=False,m_quality=None):

	CHECK_LOGIN()
	if m_quality is not None and m_quality != 'choose':
		max_quality = m_quality
	else:
		max_quality = int(__settings__.getSetting("max_quality"))
	for i in range(10):
		error = ''

		tok = getData_Sdarot(url=DOMAIN+"/ajax/watch",timeout=1,postData="preWatch=true&SID="+series_id+"&season="+season_id+"&ep="+episode_id,referer=referer)
		try:
			page = getData_Sdarot(url=DOMAIN+"/ajax/watch",timeout=1,postData="watch=true&token="+tok+"&serie="+series_id+"&season="+season_id+"&episode="+episode_id,referer=referer)
			prms=json.loads(page)
			if prms.has_key("error"):
				if tv_mode=="0":
				 dp = xbmcgui.DialogProgress()
				 dp.create("לצפייה באיכות HD וללא המתנה ניתן לרכוש מנוי", "אנא המתן 30 שניות", '', "[COLOR orange][B]לרכישת מנוי להיכנס בדפדפן - www.sdarot.click/donate[/B][/COLOR]")
				 dp.update(0)
				for s in range(30,-1,-1):
					time.sleep(1)
					if tv_mode=="0":
					 dp.update(int((30-s)/30.0 * 100), "אנא המתן 30 שניות", 'עוד {0} שניות'.format(s), '')
					 if dp.iscanceled(): 
					 	dp.close()
						return None,None
				page = getData_Sdarot(url=DOMAIN+"/ajax/watch",timeout=1,postData="watch=true&token="+tok+"&serie="+series_id+"&season="+season_id+"&episode="+episode_id,referer=referer)
		except Exception as e:
			if __debuging__=="DEBUG_MODE":
			 logging.warning(str(e))
			pass
		
		token = None

		try:

			prms=json.loads(page)
			if prms.has_key("error"):
				error = str(prms["error"].encode("utf-8"))
				if len(error) > 0 :
					time.sleep(5)
					if __debuging__=="DEBUG_MODE":
					 logging.warning(error)
					continue
			
			vid_url = str(prms["url"])

			quality = 0
			watch = prms["watch"]
			qualities = []
			for k, v in watch.iteritems():
				qualities.append(k)
				k = int(k)
				if k > quality and k <= max_quality:
					quality = k
					token = v
			if m_quality == 'choose':
				return qualities
			
			VID = str(prms["VID"])
			vid_time = str(prms["time"])
			break
		
		except Exception as e:
			error = e
			time.sleep(5)
			if __debuging__=="DEBUG_MODE":
			 logging.warning(str(e))

	
	if error <> '':
		xbmc.log('error:'+str(error), 3)
		if not silent:
			xbmcgui.Dialog().ok('Error occurred',str(error))
		return None,None
		
	if not token:
		if not silent:
			xbmcgui.Dialog().ok('Error occurred',"התוסף לא הצליח לקבל אישור לצפייה, אנא נסה מאוחר יותר")
		return None,None
	finalUrl = "http://" + vid_url + "/watch/" + str(quality) + "/" + VID + '.mp4?token=' + token + '&time=' + vid_time
	
	if __settings__.getSetting("use_proxy") == "true":
		finalUrl = "http://127.0.0.1:{0}/?url={1}".format(PROXY_PORT, urllib.quote(finalUrl))

	return "{0}|Referer={1}&User-Agent={2}".format(finalUrl, urllib.quote(referer), __USERAGENT__), VID
	#return finalUrl, VID
def CHECK_LOGIN():
	# check's if login  is required.
	#print "check if logged in already"
	if __settings__.getSetting('username').strip() == '' or __settings__.getSetting('user_password') == '':
		return
		
	page = getData_Sdarot(DOMAIN+'/series',referer=DOMAIN)
	#print page
	match = re.compile('<span class="button blue" id="logout"><a href=".*?/log(.*?)">').findall(page)
	#print match
	if match:
		if str(match[0])!='out':
		#	print "login required"
			LOGIN()
		#else:
		#	print "already logged in."
	else:
		LOGIN()
def LOGIN():
	#print("LOGIN  is running now!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
	loginurl = DOMAIN+'/login'
	if __settings__.getSetting('username')=='':
		dialog = xbmcgui.Dialog()
		xbmcgui.Dialog().ok('Sdarot','www.sdarot.tv התוסף דורש חשבון  חינמי באתר' ,' במסך הבא יש להכניס את שם המשתמש והסיסמא')
		search_entered = ''
		keyboard = xbmc.Keyboard(search_entered, 'נא הקלד שם משתמש')
		keyboard.doModal()
		if keyboard.isConfirmed():
			search_entered = keyboard.getText() 
		__settings__.setSetting('username',search_entered)
		
	if __settings__.getSetting('user_password')=='':
		search_entered = ''
		keyboard = xbmc.Keyboard(search_entered, 'נא הקלד סיסמא')
		keyboard.doModal()
		if keyboard.isConfirmed():
			search_entered = keyboard.getText()
		__settings__.setSetting('user_password',search_entered)

	username = __settings__.getSetting('username')
	password = __settings__.getSetting('user_password')
	if not username or not password:
		print "Sdarot tv:no credencials found skipping login"
		return
	
	print "Trying to login to sdarot tv site username:" + username
	page = getData_Sdarot(url=loginurl,timeout=0,postData="username=" + username + "&password=" + password +"&submit_login=התחבר",referer=DOMAIN);
   
   
##################################################YOUTUBE##############################################
def Youtube_Playlists(tv_mode):
# try:
 
  if tv_mode=="0" or tv_mode=="2":
   dp = xbmcgui.DialogProgress()
   dp.create("טוען תוכניות", "", '', "[COLOR orange][B]אנא המתן...[/B][/COLOR]")
   dp.update(0, "מעדכן...",'','')
  list=[]
  list2=[]
  names=[]
  names2=[]
  #tv_mode=__settings__.getSetting(id = 'deviceId')
  #youtube_playlists= open('d:\youtube_playlist.txt','r').read()
  if tv_mode=="2" or tv_mode=="3":
   list_location='https://raw.githubusercontent.com/ebs111/ebs_repo/master/youtube_playlist_little.html'
  else:
   list_location='https://raw.githubusercontent.com/ebs111/ebs_repo/master/youtube_playlist.html'
  contentType, playlists = getData(list_location)
  youtube_playlists = re.compile('List"(.+?)"EndList').findall(playlists)
  #with open('http://ebs.netai.net/Repository/youtube_playlist.txt') as f:
  #  youtube_playlists = f.readlines() 
  x=0
  for link in  youtube_playlists:
   try:

    
    if tv_mode=="0" or tv_mode=="2":
      contentType, page = getData(link)
      matche = re.compile('<div class="playlist-info">.+?<ul class="playlist-details">',re.DOTALL).findall(page)

      matches = re.compile('data-sessionlink="ei=(.+?)" >(.+?)</a>').findall(matche[0])

      matches3 = re.compile('data-thumbnail-url="(.+?).jpg').findall(page)
      names.append(html_decode(matches[0][1]))
    
    list.append(link)
    if tv_mode=="0" or tv_mode=="2":
      dp.update(int((x)/float(len(youtube_playlists)) * 100), "מעדכן..."+str(x)+'/'+str(len(youtube_playlists)) +'-'+ matches[0][1],'','')

      if dp.iscanceled(): 
       dp.close()
            
       playlist=''
       break
    x=x+1
    if tv_mode=="0" or tv_mode=="2":
     addDir3(html_decode(matches[0][1]),link,7,matches3[0]+'.jpg',matches3[0]+'.jpg',html_decode(matches[0][1]),"0")
   except Exception as e:    #xbmc.Player().play(playback_url)
     if __debuging__=="DEBUG_MODE":
      logging.warning("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2"+ str(e) + " " + link)
     pass       #xbmc

  if tv_mode=="1" or tv_mode=="3":
    
    show=random.choice(list)
   
    #name_fix=names[list.index(show)]
    xbmcgui.Dialog().notification('Tv', '', xbmcgui.NOTIFICATION_INFO ,100)
    contentType, page = getData(show)
    
    matche = re.compile('data-video-id="(.+?)"').findall(page)
    matche2 = re.compile('data-video-title="(.+?)"').findall(page)
    matche3 = re.compile('data-thumbnail-url="(.+?)"').findall(page)
    
    for link in  matche:
     
     name=matche2[matche.index(link)]
     image=matche3[matche.index(link)]
    
     name=html_decode(name)
    #logging.warning(link)
    #link='https://www.youtube.com/watch?v='+link
    #addLink(contentType, name, link, image, str(0), "")
     if not 'Deleted video'  in name:
      if not 'Private video' in name:
       list2.append(link)
       names2.append(name)
       if tv_mode=="0" or tv_mode=="2":
        addDir3(name,link,8,image,image,name,"0")
    if tv_mode=="1" or tv_mode=="3":
        show2=random.choice(list2)

        name_fix=names2[list2.index(show2)]
        xbmcgui.Dialog().notification('Tv', name_fix, xbmcgui.NOTIFICATION_INFO,1000 )
        video_id = show2
        playback_url = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % video_id
        if __debuging__=="DEBUG_MODE":
         logging.warning("Player_Start_Now")
        
        return playback_url,name_fix
 #except Exception as e:    #xbmc.Player().play(playback_url)
 #    if __debuging__=="DEBUG_MODE":
 #     logging.warning("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2"+ str(e))
 #    pass       #xbmc.Player().play(playback_url)

        #sys.exit()
def read_txt_files(target_url):
  try:
 
   target_url=target_url.rstrip('\r\n')
   if os.path.isfile(target_url):
    
    f=open(target_url, 'r') 
   else:
    f = urllib2.urlopen(target_url)
   return f.readlines()
  except:
    print 'ERROR: defname'
    #traceback.print_exc()
    return 'ERROR'
def Trailer_Youtube(tv_mode):
  try:
  
   #tv_mode=__settings__.getSetting(id = 'deviceId')
   list=[]
   names=[]
   now = datetime.datetime.now()
   x=0
   #link_url='https://www.youtube.com/results?search_query='+ str(now.year) + '+%22%D7%98%D7%A8%D7%99%D7%99%D7%9C%D7%A8+%D7%9E%D7%93%D7%95%D7%91%D7%91%22'
   link_url='https://www.youtube.com/results?sp=CAI%253D&q=%22%D7%98%D7%A8%D7%99%D7%99%D7%9C%D7%A8+%D7%9E%D7%93%D7%95%D7%91%D7%91%22+' + str(now.year)
   contentType, page = getData(link_url)

   matche = re.compile('yt-lockup yt-lockup-tile yt-lockup-video vve-check clearfix(.+?)</div></div></div>',re.DOTALL).findall(page)
   for links in matche:
    link=re.compile('<a href="(.+?)"').findall(links)
    name=re.compile('title="(.+?)"').findall(links)
    
    
    x=x+1
    link[0]=link[0][9:]

    name_final=name[0]
    if "Watch Later" in name[0]:
       name_final=name[1]
    if "Queue" in name[1]:
       name_final=name[2]
    list.append(link[0])
    names.append(html_decode(name_final))
    image=re.compile('<img.+?"https:(.+?)"',re.DOTALL).findall(links)
    if tv_mode=="0":
     addDir3(html_decode(name_final),link[0],8,'https:'+image[0],'https:'+image[0],html_decode(name_final),"0") 
   
   link_url='https://www.youtube.com/results?q='+ str(now.year) + '+%22%D7%98%D7%A8%D7%99%D7%99%D7%9C%D7%A8+%D7%9E%D7%93%D7%95%D7%91%D7%91%22&sp=SBTqAwA%253D'
   contentType, page = getData(link_url)

   matche = re.compile('yt-lockup yt-lockup-tile yt-lockup-video vve-check clearfix(.+?)</div></div></div>',re.DOTALL).findall(page)
   for links in matche:
    
    link=re.compile('<a href="(.+?)"').findall(links)
    name=re.compile('title="(.+?)"').findall(links)

    link[0]=link[0][9:]

    name_final=name[0]
    if "Watch Later" in name[0]:
       name_final=name[1]
    if "Queue" in name[1]:
       name_final=name[2]
    list.append(link[0])
    names.append(html_decode(name_final))
    image=re.compile('<img.+?"https:(.+?)"',re.DOTALL).findall(links)
    if tv_mode=="0":
     addDir3(html_decode(name_final),link[0],8,'https:'+image[0],'https:'+image[0],'https:'+image[0],"0") 
   if tv_mode=="1":
      
      show=random.choice(list)
      name_fix=names[list.index(show)]
      xbmcgui.Dialog().notification('Tv', name_fix, xbmcgui.NOTIFICATION_INFO,1000 )
      video_id = show
      playback_url = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % video_id
      if __debuging__=="DEBUG_MODE":
       logging.warning("Player_Start_Now")
      return playback_url,name_fix
  except Exception as e:    #xbmc.Player().play(playback_url)
   if __debuging__=="DEBUG_MODE":
    logging.warning("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF3"+ str(e))
   pass
def html_decode(s):
   try:
    """
    Returns the ASCII decoded version of the given HTML string. This does
    NOT remove normal HTML tags like <p>.
    """
    htmlCodes = (
            ("'", '&#39;'),
            ('"', '&quot;'),
            ('>', '&gt;'),
            ('<', '&lt;'),
            ('&', '&amp;')
        )
    for code in htmlCodes:
        s = s.replace(code[1], code[0])
    return s
   except Exception as e:    #xbmc.Player().play(playback_url)
    if __debuging__=="DEBUG_MODE":
     logging.warning("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4"+ str(e))
    pass
	
def Youtube_Playlists_Pop(url):
 try:
   contentType, page = getData(url)

   matche = re.compile('data-video-id="(.+?)"').findall(page)
   matche2 = re.compile('data-video-title="(.+?)"').findall(page)
   matche3 = re.compile('data-thumbnail-url="(.+?)"').findall(page)
   
   for link in  matche:
    name=matche2[matche.index(link)]
    image=matche3[matche.index(link)]
    
    name=html_decode(name)
    #logging.warning(link)
    #link='https://www.youtube.com/watch?v='+link
    #addLink(contentType, name, link, image, str(0), "")
    if not 'Deleted video'  in name:
     if not 'Private video' in name:
      addDir3(name,link,8,image,image,name,"0")
 except Exception as e:
   if __debuging__=="DEBUG_MODE": 
    logging.warning("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF1"+ str(e))
   pass
   
   
def getMatches(url, pattern):

 try:
        contentType, page = getData(url)
        matches = re.compile(pattern).findall(page)
        return contentType, matches 
 except Exception as e:
   if __debuging__=="DEBUG_MODE":
    logging.warning("5FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"+ str(e))
 
   pass

def getData(url):

 try:
        #print url
            req = urllib2.Request(url)
            req.add_header('User-Agent', __USERAGENT__)
            response = urllib2.urlopen(req)
            contentType = response.headers['content-type']

            data = response.read().replace("\n", "").replace("\t", "").replace("\r", "")
           
            response.close()            
            

            return contentType, data
 except Exception as e:
   if __debuging__=="DEBUG_MODE":
    logging.warning("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF6"+ str(e))
   pass
##################################################NickJr##############################################
def NickJr(tv_mode):
 #try:
    #tv_mode=__settings__.getSetting(id = 'deviceId')
    
    list=[]
    url='http://nickjr.walla.co.il/'
    #r = requests.get(url)
    contentType, page = getData(url)
    matche = re.compile('<div id="folder2_show".+?<span class="wcflow"></span>',re.DOTALL).findall(page)
    matches=re.compile('<a href="(.+?)" class="item right w3" style="margin-left: 0px;">(.+?)</a>').findall(matche[0])
    #matches = re.compile('<a id="opc" href="(.+?)".+?<img id="(.+?)" src="(.+?)" class="nav_image zoom1"  alt="(.+?)" title="">',re.DOTALL).findall(page)
                                             
    for link,name in matches:

      if __BASENICKJADD__ not in link:
       link=__BASENICKJADD__+link
      #contentType, page = getData(link)
      #matche = re.compile('<div class="top_stripe_div".+?<img src="(.+?)">').findall(page)
      #if (len(matche)>0):
      # image=matche[0]
      #else:
      image=""
      list.append((link,name))
      if tv_mode=="0":
       addDir3(clean(contentType,name),link,3,image,image,clean(contentType,name),"0")
      
    if tv_mode=="1":
     show=random.choice(list)
     #addDir3(clean(contentType,name),link,"",image,image,link,"0")
     while "2678298"  in show[0]:
       show=random.choice(list)
     logging.warning(show)
     show2=GetNickEpisodeList(show[0],tv_mode)
     return show2,clean(contentType,show[1])
 #except Exception as e:    #xbmc.Player().play(playback_url)
 #  if __debuging__=="DEBUG_MODE":
#    logging.warning("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7"+ str(e))
 #  pass
    #contentType,block = getMatches(url,'padding: 10px(.*?)folder2_game')
    #page = re.compile('<a href="(.*?)".*?0px;">(.*?)<').findall(block[0])

    #for path in page:
    #            summary = ''
    #            iconImage=''
    #            url2=url + path[0]
    #            #iconImage=getImageNick(url)
    #                   
    #            
    #            title=path[1]
    #            addDir3(title,url2,3,"","",title)


def GetNickEpisodeList(url,tv_mode):
 
  try:
   #tv_mode=__settings__.getSetting(id = 'deviceId')
    
    list=[]
    list_name=[]
    Episode = namedtuple('Episode', ['content', 'title', 'url', 'iconImage', 'time', 'epiDetails'])    
    #r = requests.get(url+'/@@/video/flv_pl')
    
    contentType, page = getData(url)
    matches = re.compile('vitem301 mb37.+?<img class="imgdiv301 imgcls" alt="(.+?)" title="(.+?)" src="(.+?)">.+?<div class="title w5b mt5"><a href="(.+?)" >',re.DOTALL).findall(page)
                                                
    for demi1,name,image,link2 in matches:
      if len(name)>100:
        name="No Name"
      
      r = requests.get(__BASENICKJADD__+link2  + '/@@/video/flv_pl')
      link='http://62.90.90.56/walla_vod/_definst_/'+ re.compile('<src>(.*?)</src>').findall(r.content)[0]+'.mp4/playlist.m3u8'
      
      list.append(link)
      list_name.append(name)
      if tv_mode=="0":
       addLink(contentType, name, link, image, str(0), "")
    
    matches = re.compile('vitem mb37 right.+?<img src="(.+?)" alt="".+?<div class="title w4b"><a href="(.+?)" >(.+?)</a></div>',re.DOTALL).findall(page)
                                                
    for image,link2,name in matches:
      if len(name)>100:
        name="No Name"
      r = requests.get(__BASENICKJADD__+link2  + '/@@/video/flv_pl')
      link='http://62.90.90.56/walla_vod/_definst_/'+ re.compile('<src>(.*?)</src>').findall(r.content)[0]+'.mp4/playlist.m3u8'
      list.append(link)
      list_name.append(name)
      if tv_mode=="0":
       addLink(contentType, name, link, image, str(0), "")

    logging.warning("Mid Nick")
    contentType, page = getData(url)
    matche = re.compile('<a class="p_r" style="" href=".+?span class="pg pg_curr">',re.DOTALL).findall(page)
    if (len(matche)>0):
     matches = re.compile('<a href="(.+?)" class="pg">',re.DOTALL).findall(matche[0])
     for link in reversed(matches):
      
      contentType, page = getData(__BASENICKJADD__+link)
      matches = re.compile('vitem301 mb37.+?<img class="imgdiv301 imgcls" alt="(.+?)" title="(.+?)" src="(.+?)">.+?<div class="title w5b mt5"><a href="(.+?)" >',re.DOTALL).findall(page)
                                                
      for demi1,name,image,link2 in matches:
       if len(name)>100:
         name="No Name"
       r = requests.get(__BASENICKJADD__+link2  + '/@@/video/flv_pl')
       link='http://62.90.90.56/walla_vod/_definst_/'+ re.compile('<src>(.*?)</src>').findall(r.content)[0]+'.mp4/playlist.m3u8'
       list.append(link)
       list_name.append(name)
       if tv_mode=="0":
        addLink(contentType, name, link, image, str(0), "")

    
      matches = re.compile('vitem mb37 right.+?<img src="(.+?)" alt="".+?<div class="title w4b"><a href="(.+?)" >(.+?)</a></div>',re.DOTALL).findall(page)
                                                
      for image,link2,name in matches:
       if len(name)>100:
         name="No Name"
       r = requests.get(__BASENICKJADD__+link2  + '/@@/video/flv_pl')
       link='http://62.90.90.56/walla_vod/_definst_/'+ re.compile('<src>(.*?)</src>').findall(r.content)[0]+'.mp4/playlist.m3u8'
       list.append(link)
       list_name.append(name)
       if tv_mode=="0":
        addLink(contentType, name, link, image, str(60), "")
    if tv_mode=="1":
        show=random.choice(list)
        name_fix=clean(contentType,list_name[list.index(show)])
        listitem =xbmcgui.ListItem (name_fix)
 
        listitem.setInfo('video', {'Title': name_fix, 'Genre': 'Kids'})
        if __debuging__=="DEBUG_MODE":
         logging.warning("Player_Start_Now")
        return show
		#xbmc.Player().play(show, listitem, False)
  except Exception as e:    #xbmc.Player().play(playback_url)
   if __debuging__=="DEBUG_MODE":
    logging.warning("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8"+ str(e))
   pass
        #xbmc.Player().play(item=show)
        #player.play(item=show)
        


        


       
        
        #if xbmc.Player().onPlayBackEnded():

       #addDir3(clean(contentType,name),link,1,image,image,link)

     
	

   
   

  
	  
def OPEN_URL_Youtube(url,name):
 try:
  video_id = url
  playback_url = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % video_id
  
  xbmc.Player().play(playback_url)
  sys.exit()
 except Exception as e:    #xbmc.Player().play(playback_url)
   if __debuging__=="DEBUG_MODE":
    logging.warning("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9"+ str(e))
   pass
 

  #video_id = url
  #playback_url = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % video_id
  #logging.warning(playback_url)
  #item = xbmcgui.ListItem(path=playback_url)
  #xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
 
  

def tv_mode_Menu(tv_type):
   dp = xbmcgui.DialogProgress()
   dp.create("מכין תוכניות לצפייה", "", '', "[COLOR orange][B]אנא המתן...[/B][/COLOR]")
   dp.update(0, "מעדכן...",'','')
   tv_mode_count=int(__settings__.getSetting(id = 'deviceId'))
   if tv_mode_count<1:
    tv_mode_count=1
   remotePlaylist=""
   list2=[]
   names_all=[]
   x=0
   player = xbmc.Player()
   playerItem = xbmcgui.ListItem(remotePlaylist)
   playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
   playlist.clear()
   

   #__settings__.setSetting(id = 'deviceId', value = "1")
   names=''
   prev_random=0
   random_choise=0
   while x<tv_mode_count:
    try:
     while prev_random==random_choise:
       random_choise=random.randrange(1, 11)
     prev_random=random_choise
     #random_choise=5
     if random_choise>5:
      random_choise=5
     if x==0 and random_choise==5:
      random_choise=1
     logging.warning("Random:"+str(random_choise))
     if (tv_type==0):
      if random_choise==1:
       link2,names=NickJr("1")
      if random_choise==2:
       link2,names=Youtube_Playlists("1")
      if random_choise==3:
       link2,names=Trailer_Youtube("1")
      if random_choise==4:
       link2,names=getSeriesList("1")
      if random_choise==5:
       link2,names=Sdarot_Tv('all-heb','https://www.sdarot.live/series/genre/38-\xd7\x99\xd7\x9c\xd7\x93\xd7\x99\xd7\x9d',"1")

   
     if (tv_type==1):
       
       link2,names=Youtube_Playlists("3")
       logging.warning(link2)
     if (link2 not in list2) and (link2 is not None) and (names not in names_all)  :
 
       list2.append(link2)
       names_all.append(names)
       logging.warning("Add:"+link2)
       logging.warning("Location: "+str(x))
       listItem=xbmcgui.ListItem(names, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
     
       #listItem.setProperty("PlayPath", link2)
       listItem.setInfo('video', {'Title': names, 'Genre': 'Kids'})
       playlist.add(url=link2, listitem=listItem)

       
       player_status=xbmc.Player().isPlaying()

       if (not xbmc.Player().isPlaying()) and x>0:
          logging.warning('User Stoped')
          xbmcgui.Dialog().notification('Tv', "User Stoped", xbmcgui.NOTIFICATION_INFO,1000 )
          
          break
       else:
          xbmcgui.Dialog().notification('Tv',str(random_choise)+ " מוסיף לרשימה:" + str(x), xbmcgui.NOTIFICATION_INFO,1000 )
       x=x+1
       if x==1:
         dp.close()
         xbmc.Player().play(playlist, playerItem, False)
     

     
     
     
    except Exception as e:
       if __debuging__=="DEBUG_MODE":
        logging.warning("ZZZZZZZZZZZZZZZZZZZZZZZZZZZ" + str(e)) 
       pass
   if __debuging__=="DEBUG_MODE":
    logging.warning("ZZZZZZZZZZZZZZZZZZZZZZZZZZZ" + str(x))
   #xbmc.Player().play(playlist, playerItem, False)
   sys.exit()


   
def get_params():

        param=[]
        
        
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param       
#################################################################################################################

#                               NEED BELOW CHANGED


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
     

###############################################################################################################        
def addLink(contentType, name, url, iconimage='DefaultFolder.png', time='', sub=''):
        liz = xbmcgui.ListItem(clean(contentType, name), iconImage=iconimage, thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote(clean(contentType, name)), "Duration":time, "Plot": urllib.unquote(sub)})
        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=liz)
        return ok
def addDir2(name,url,mode,iconimage,fanart,description,tv_mode):

        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&tv_mode="+urllib.quote_plus(tv_mode)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
       # xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)
        return ok
		
def addDir3(name,url,mode,iconimage,fanart,description,tv_mode):

        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&tv_mode="+urllib.quote_plus(tv_mode)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
       # xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)
        return ok


#r = requests.get("http://reshet.tv/entertainment/the-voice/")

#match = re.compile(('"postType":"item","post_name":"(.+?)","ID":(.+?),"title":"(.+?)","link":"(.+?)","target":(.+?),"images":{"app_feed":"(.+?)"')).findall(r.content)
#biggest="0"
#big=["0","0"]
#j=0
#listing = []
#for name,id,title,link,target,image in match:
       
#       if len(title)<500 and len(link)<500:

         
#          category = title.decode('unicode_escape').encode('utf-8')
          
#          link_new=link.split("\\/")
         
#          j=0
#          for item in link_new:
#            if item.find("season") != -1:
             
#             big=item.split("-")
#            if int(biggest)<int(big[1]):
            
#             biggest=big[1]

#            j=j+1
#                    # Create a list item with a text label and a thumbnail image.

#            listing.append((category,link.replace('\\/', '/'),1,image.replace('\\/', '/'),"",""))
#    # Add our listing to Kodi.
#    # Large lists and/or slower systems benefit from adding all items at once via addDirectoryItems
#    # instead of adding one by ove via addDirectoryItem.

          
#          #addDir3(category,link.replace('\\/', '/'),1,image.replace('\\/', '/'),"","",)


       
#addDir3("תוספות",link,5,image,"","",)
 		               
#NickJr('http://nickjr.walla.co.il/')
   
#GetNickEpisodeList('http://nickjr.walla.co.il/?w=//2775381')

params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
tv_mode="0"
summary=None
quality=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:
	summary=urllib.unquote_plus(params["summary"])
except:
    pass
try:
	quality=int(params["quality"])
except:
	pass

#if tv_mode=="1" and  xbmc.Player().isPlaying()==False:
# logging.warning("False Playing")
# mode=5
#else:
# logging.warning("True Playing")
# mode=None


#if tv_mode=="1" and  xbmc.Player().onPlayBackStopped()==True:
#  mode=None

#__settings__.openSettings()
def find_all(a_string, sub):
    result = []
    k = 0
    while k < len(a_string):
        k = a_string.find(sub, k)
        if k == -1:
            return result
        else:
            result.append(k)
            k += 1 #change to k += len(sub) to not search overlapping results
    return result
		

#logfile = open(xbmc.translatePath(__LOG_FILE_LOC)  + "kodi.log",'r').read() 

#matches=find_all(logfile, 'Player_Start_Now')
#matches2 =find_all(logfile, 'CloseFile')
#tv_mode=__settings__.getSetting(id = 'deviceId')
#matches = re.compile('Player_(.+?)_Now').findall(logfile)
#matches2 = re.compile('CApplication::OnPlayBackStopped(.+?)play').findall(logfile)

#logging.warning(str((matches)))
#logging.warning(str((matches2)))
#logging.warning(tv_mode)
#if (len(matches)>0) and (len(matches2)>0):
#  logging.warning(str((matches2[len(matches2)-1])))
# logging.warning(str((matches[len(matches)-1])))
#  if ((matches2[len(matches2)-3])>(matches[len(matches)-1])) and tv_mode=="1" :
    #logging.warning("Stop NOW")
    #__settings__.setSetting(id = 'deviceId', value = "0")
    #mode=None


if mode==None or url==None or len(url)<1:
        #logging.warning("Start OVER")
        CATEGORIES()
       
elif mode==2:
        NickJr("0")
elif mode==3:
        GetNickEpisodeList(url,"0")
elif mode==5:  
        tv_mode_Menu(0)        
elif mode==6:  
        Youtube_Playlists("0")  
elif mode==7:  
        Youtube_Playlists_Pop(url)  
elif mode==8:
        OPEN_URL_Youtube(url,name)
elif mode==9:
        Trailer_Youtube("0")
elif mode==10:
        Sdarot_Tv('all-heb','https://www.sdarot.live/series/genre/38-\xd7\x99\xd7\x9c\xd7\x93\xd7\x99\xd7\x9d',"0")
elif mode==11:
        sdarot_series(url,"","0")
elif mode==12:
        sdarot_season(url, summary,"0")
elif mode==13:
        sdarot_movie(url, summary,"", quality,"0")
elif mode==14:
        clean_cache()
        xbmc.executebuiltin("XBMC.Notification({0}, המטמון נמחק, {1}, {2})".format(addonName, 5000 ,addonIcon))
elif mode==15:
        update_view(url)
elif mode==16:
        Movies_Addson()
elif mode==17:
        getSeriesList("0")
elif mode==18:
        getEpisodeList_Nick(url,"0")
elif mode==19:
        Youtube_Playlists("2")  
elif mode==20:
        tv_mode_Menu(1) 
		
		
xbmcplugin.endOfDirectory(int(sys.argv[1]))
