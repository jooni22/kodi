import zipfile, xbmcaddon, xbmc, sys, os, time



KODIV          = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
if KODIV > 17:
	import zfile as zipfile #FTG mod for Kodi 18
else:
	import zipfile


def all(_in, _out, dp=None):
	if dp:
		return allWithProgress(_in, _out, dp)

	return allNoProgress(_in, _out)
		

def allNoProgress(_in, _out):
	try:
		zin = zipfile.ZipFile(_in, 'r')
		zin.extractall(_out)
	except Exception, e:
		return False

	return True


def allWithProgress(_in, _out, dp):

	zin = zipfile.ZipFile(_in,  'r')

	nFiles = float(len(zin.infolist()))
	count  = 0

	try:
		for item in zin.infolist():
			count += 1
			update = count / nFiles * 100
			affupdate = str(int(update)) + '%s'%' %'
			dp.update(int(update),'','Extracting : [COLOR %s][B]%s[/B][/COLOR]'% ('cyan', affupdate) , 'Please Wait')
			zin.extract(item, _out)
	except Exception, e:
		return False

	return True
