__author__ = 'bromix'

from resources.lib.youtube.helper import yt_subscriptions
from resources.lib import kodion
from resources.lib.kodion.utils import FunctionCache
from resources.lib.kodion.items import *
from resources.lib.youtube.client import YouTube
from .helper import v3, ResourceManager, yt_specials, yt_playlist, yt_login, yt_setup_wizard, yt_video, \
    yt_context_menu, update_video_infos, update_fanarts, update_channel_infos
from .youtube_exceptions import LoginException


class Provider(kodion.AbstractProvider):
    COLLECTION_DUMMY = {'Games': ['UCJ2ZDzMRgSrxmwphstrm8Ww', 'UC7_YxT-KID8kRbqZo7MyscQ', 'UC84X0epDRFdTrybxEX8ZWkA',
                                  'UC-lHJZR3Gqxm24_Vd_AJ5Yw', 'UCboMX_UNgaPBsUOIgasn3-Q', 'UCEBWPOf6l9yXnAzHwuQ220g',
                                  'UCyS4xQE6DK4_p3qXQwJQAyA', 'UCaDFEed7JBxC2lnP5I2AktQ', 'UCLx053rWZxCiYWsBETgdKrQ'],
                        'Fun & Stuff': ['UCEkZHiGsR4jvWeHunEB3Qaw', 'UClmmbesFjIzJAp8NQCtt8dQ', 'UCPDis9pjXuqyI7RYLJ-TTSA']}
    LOCAL_MAP = {'youtube.channels': 30500,
                 'youtube.playlists': 30501,
                 'youtube.go_to_channel': 30502,
                 'youtube.subscriptions': 30504,
                 'youtube.unsubscribe': 30505,
                 'youtube.subscribe': 30506,
                 'youtube.my_channel': 30507,
                 'youtube.watch_later': 30107,
                 'youtube.refresh': 30543,
                 'youtube.history': 30509,
                 'youtube.my_subscriptions': 30510,
                 'youtube.remove': 30108,
                 'youtube.delete': 30118,
                 'youtube.browse_channels': 30512,
                 'youtube.popular_right_now': 30513,
                 'youtube.related_videos': 30514,
                 'youtube.setting.auto_remove_watch_later': 30515,
                 'youtube.subscribe_to': 30517,
                 'youtube.sign.in': 30111,
                 'youtube.sign.out': 30112,
                 'youtube.sign.go_to': 30518,
                 'youtube.sign.enter_code': 30519,
                 'youtube.sign.twice.title': 30546,
                 'youtube.sign.twice.text': 30547,
                 'youtube.playlist.select': 30521,
                 'youtube.playlist.play.all': 30531,
                 'youtube.playlist.play.default': 30532,
                 'youtube.playlist.play.reverse': 30533,
                 'youtube.playlist.play.shuffle': 30534,
                 'youtube.playlist.play.select': 30535,
                 'youtube.playlist.play.from_here': 30537,
                 'youtube.playlist.progress.updating': 30536,
                 'youtube.rename': 30113,
                 'youtube.playlist.create': 30522,
                 'youtube.setup_wizard.select_language': 30524,
                 'youtube.setup_wizard.select_region': 30525,
                 'youtube.setup_wizard.adjust': 30526,
                 'youtube.setup_wizard.adjust.language_and_region': 30527,
                 'youtube.video.add_to_playlist': 30520,
                 'youtube.video.liked': 30508,
                 'youtube.video.description.links': 30544,
                 'youtube.video.description.links.not_found': 30545,
                 'youtube.video.disliked': 30538,
                 'youtube.video.queue': 30511,
                 'youtube.video.rate': 30528,
                 'youtube.video.rate.like': 30529,
                 'youtube.video.rate.dislike': 30530,
                 'youtube.video.rate.none': 30108,
                 'youtube.video.play_with': 30540,
                 'youtube.video.more': 30548,
                 'youtube.live': 30539,
                 'youtube.error.no_video_streams_found': 30549,
                 'youtube.error.rtmpe_not_supported': 30542}

    def __init__(self):
        kodion.AbstractProvider.__init__(self)
        self._resource_manager = None

        self._client = None
        self._is_logged_in = False
        pass

    def get_wizard_supported_views(self):
        return ['default', 'episodes']

    def get_wizard_steps(self, context):
        return [(yt_setup_wizard.process, [self, context])]

    def is_logged_in(self):
        return self._is_logged_in

    def reset_client(self):
        self._client = None
        pass

    def get_client(self, context):
        # set the items per page (later)
        items_per_page = context.get_settings().get_items_per_page()

        access_manager = context.get_access_manager()
        access_tokens = access_manager.get_access_token()
        if access_manager.is_new_login_credential() or not access_tokens or access_manager.is_access_token_expired():
            # reset access_token
            access_manager.update_access_token('')
            # we clear the cache, so none cached data of an old account will be displayed.
            context.get_function_cache().clear()
            # reset the client
            self._client = None
            pass

        if not self._client:
            youtube_config = {'system': 'All',
                              'key': 'AIzaSyCS4vnE11VlnnFw9QkmTvd1tL4snD6ixAw',
                              'id': '788424101709-eua9ji2pnvsr3sebjibi66c5b7c8f4ir.apps.googleusercontent.com',
                              'secret': 'tDE9VwassWSW_AkRzU3RTNrJ'}

            language = context.get_settings().get_string('youtube.language', 'en-US')

            # remove the old login.
            if access_manager.has_login_credentials():
                access_manager.remove_login_credentials()
                pass

            if access_manager.has_login_credentials() or access_manager.has_refresh_token():
                # username, password = access_manager.get_login_credentials()
                access_tokens = access_manager.get_access_token()
                refresh_tokens = access_manager.get_refresh_token()

                # create a new access_token
                if not access_tokens and refresh_tokens:
                    try:
                        access_token, expires_in = YouTube(language=language, config=youtube_config).refresh_token(
                            refresh_tokens)
                        access_manager.update_access_token(access_token, expires_in)
                    except LoginException, ex:
                        access_tokens = ''
                        # reset access_token
                        access_manager.update_access_token('')
                        # we clear the cache, so none cached data of an old account will be displayed.
                        context.get_function_cache().clear()
                        pass
                    pass

                # in debug log the login status
                self._is_logged_in = access_tokens != ''
                if self._is_logged_in:
                    context.log_debug('User is logged in')
                else:
                    context.log_debug('User is not logged in')
                    pass

                self._client = YouTube(language=language, items_per_page=items_per_page, access_token=access_tokens,
                                       config=youtube_config)
                self._client.set_log_error(context.log_error)
            else:
                self._client = YouTube(items_per_page=items_per_page, language=language, config=youtube_config)
                self._client.set_log_error(context.log_error)

                # in debug log the login status
                context.log_debug('User is not logged in')
                pass
            pass

        return self._client

    def get_resource_manager(self, context):
        if not self._resource_manager:
            # self._resource_manager = ResourceManager(weakref.proxy(context), weakref.proxy(self.get_client(context)))
            self._resource_manager = ResourceManager(context, self.get_client(context))
            pass
        return self._resource_manager

    def get_alternative_fanart(self, context):
        return self.get_fanart(context)

    def get_fanart(self, context):
        return context.create_resource_path('media', 'fanart.jpg')

    @kodion.RegisterProviderPath('^/playlist/(?P<playlist_id>.*)/$')
    def _on_playlist(self, context, re_match):
        self.set_content_type(context, kodion.constants.content_type.EPISODES)

        result = []

        playlist_id = re_match.group('playlist_id')
        page_token = context.get_param('page_token', '')

        # no caching
        json_data = self.get_client(context).get_playlist_items(playlist_id=playlist_id, page_token=page_token)
        if not v3.handle_error(self, context, json_data):
            return False
        result.extend(v3.response_to_items(self, context, json_data))

        return result

    """
    Lists the videos of a playlist.
    path       : '/channel/(?P<channel_id>.*)/playlist/(?P<playlist_id>.*)/'
    channel_id : ['mine'|<CHANNEL_ID>]
    playlist_id: <PLAYLIST_ID>
    """

    @kodion.RegisterProviderPath('^/channel/(?P<channel_id>.*)/playlist/(?P<playlist_id>.*)/$')
    def _on_channel_playlist(self, context, re_match):
        self.set_content_type(context, kodion.constants.content_type.EPISODES)

        result = []

        playlist_id = re_match.group('playlist_id')
        page_token = context.get_param('page_token', '')

        # no caching
        json_data = self.get_client(context).get_playlist_items(playlist_id=playlist_id, page_token=page_token)
        if not v3.handle_error(self, context, json_data):
            return False
        result.extend(v3.response_to_items(self, context, json_data))

        return result

    def _internal_on_channels(self, context, channel_ids):
        result = []
        dialog = context.get_ui().create_progress_dialog(heading='Please wait', text='Updating channels',
                                                         background=False)
        self.set_content_type(context, kodion.constants.content_type.EPISODES)
        dialog.set_total(len(channel_ids))
        resource_manager = self.get_resource_manager(context)
        # update and cache all channels
        channel_data = resource_manager.get_channels(channel_ids)

        client = self.get_client(context)

        items = []
        for channel_id in channel_ids:
            channel_name = channel_data.get(channel_id, {}).get('snippet', {}).get('title', '')
            dialog.update(text=channel_name)
            playlists = resource_manager.get_related_playlists(channel_id)
            upload_playlist = playlists.get('uploads', '')
            if upload_playlist:
                json_data = context.get_function_cache().get(FunctionCache.ONE_HOUR,
                                                             client.get_playlist_items, upload_playlist)
                if not v3.handle_error(self, context, json_data):
                    return False

                items.extend(json_data.get('items', []))
                pass
            pass

        items = sorted(items, key=lambda x: x.get('snippet', {}).get('publishedAt', ''), reverse=True)
        items = items[:100]
        video_id_dict = {}
        for item in items:
            video_id = item['snippet']['resourceId']['videoId']
            video_item = VideoItem(item['snippet']['title'],
                                   uri=context.create_uri(['play'], {'video_id': video_id}))
            result.append(video_item)

            video_id_dict[video_id] = video_item
            pass

        channel_item_dict = {}

        update_video_infos(self, context, video_id_dict, channel_items_dict=channel_item_dict)
        update_fanarts(self, context, channel_item_dict)

        dialog.close()
        return result

    @kodion.RegisterProviderPath('^/channels/(?P<channel_ids>.*)/$')
    def _on_channels(self, context, re_match):
        channel_ids = re_match.group('channel_ids').split('|')
        return self._internal_on_channels(context, channel_ids)

    @kodion.RegisterProviderPath('^/channel/(?P<channel_id>.*)/playlists/$')
    def _on_channel_playlists(self, context, re_match):
        result = []

        channel_id = re_match.group('channel_id')
        page_token = context.get_param('page_token', '')

        # no caching
        json_data = self.get_client(context).get_playlists_of_channel(channel_id, page_token)
        if not v3.handle_error(self, context, json_data):
            return False
        result.extend(v3.response_to_items(self, context, json_data))

        return result

    """
    Lists a playlist folder and all uploaded videos of a channel.
    path      :'/channel|user/(?P<channel_id|username>.*)/'
    channel_id: <CHANNEL_ID>
    """

    @kodion.RegisterProviderPath('^/(?P<method>(channel|user))/(?P<channel_id>.*)/$')
    def _on_channel(self, context, re_match):
        self.set_content_type(context, kodion.constants.content_type.EPISODES)

        resource_manager = self.get_resource_manager(context)

        result = []

        method = re_match.group('method')
        channel_id = re_match.group('channel_id')

        """
        This is a helper routine if we only have the username of a channel. This will retrieve the correct channel id
        based on the username.
        """
        if method == 'user':
            context.log_debug('Trying to get channel id for user "%s"' % channel_id)

            json_data = context.get_function_cache().get(FunctionCache.ONE_DAY,
                                                         self.get_client(context).get_channel_by_username, channel_id)
            if not v3.handle_error(self, context, json_data):
                return False

            # we correct the channel id based on the username
            items = json_data.get('items', [])
            if len(items) > 0:
                channel_id = items[0]['id']
                pass
            else:
                context.log_warning('Could not find channel ID for user "%s"' % channel_id)
                return False
            pass

        channel_fanarts = resource_manager.get_fanarts([channel_id])
        page = int(context.get_param('page', 1))
        page_token = context.get_param('page_token', '')

        if page == 1:
            playlists_item = DirectoryItem('[B]' + context.localize(self.LOCAL_MAP['youtube.playlists']) + '[/B]',
                                           context.create_uri(['channel', channel_id, 'playlists']),
                                           image=context.create_resource_path('media', 'playlist.png'))
            playlists_item.set_fanart(channel_fanarts.get(channel_id, self.get_fanart(context)))
            result.append(playlists_item)
            pass

        playlists = resource_manager.get_related_playlists(channel_id)
        upload_playlist = playlists.get('uploads', '')
        if upload_playlist:
            json_data = context.get_function_cache().get(FunctionCache.ONE_MINUTE * 5,
                                                         self.get_client(context).get_playlist_items, upload_playlist,
                                                         page_token=page_token)
            if not v3.handle_error(self, context, json_data):
                return False

            result.extend(
                v3.response_to_items(self, context, json_data, sort=lambda x: x.get_aired(), reverse_sort=True))
            pass

        return result

    """
    Plays a video.
    path for video: '/play/?video_id=XXXXXXX'

    TODO: path for playlist: '/play/?playlist_id=XXXXXXX&mode=[OPTION]'
    OPTION: [normal(default)|reverse|shuffle]
    """

    @kodion.RegisterProviderPath('^/play/$')
    def on_play(self, context, re_match):
        video_id = context.get_param('video_id')
        return UriItem('plugin://plugin.video.youtube/play/?video_id=%s' % video_id)

    @kodion.RegisterProviderPath('^/video/(?P<method>.*)/$')
    def _on_video_x(self, context, re_match):
        method = re_match.group('method')
        return yt_video.process(method, self, context, re_match)

    @kodion.RegisterProviderPath('^/playlist/(?P<method>.*)/(?P<category>.*)/$')
    def _on_playlist_x(self, context, re_match):
        method = re_match.group('method')
        category = re_match.group('category')
        return yt_playlist.process(method, category, self, context, re_match)

    @kodion.RegisterProviderPath('^/subscriptions/(?P<method>.*)/$')
    def _on_subscriptions(self, context, re_match):
        method = re_match.group('method')
        return yt_subscriptions.process(method, self, context, re_match)

    @kodion.RegisterProviderPath('^/special/(?P<category>.*)/$')
    def _on_yt_specials(self, context, re_match):
        category = re_match.group('category')
        return yt_specials.process(category, self, context, re_match)

    @kodion.RegisterProviderPath('^/events/post_play/$')
    def _on_post_play(self, context, re_match):
        video_id = context.get_param('video_id', '')
        if video_id:
            client = self.get_client(context)
            if self.is_logged_in():
                # first: update history
                client.update_watch_history(video_id)

                # second: remove video from 'Watch Later' playlist
                if context.get_settings().get_bool('youtube.playlist.watchlater.autoremove', True):
                    playlist_item_id = client.get_playlist_item_id_of_video_id(playlist_id='WL', video_id=video_id)
                    if playlist_item_id:
                        json_data = client.remove_video_from_playlist('WL', playlist_item_id)
                        if not v3.handle_error(self, context, json_data):
                            return False
                        pass
                    pass
                pass
            pass
        else:
            context.log_warning('Missing video ID for post play event')
            pass
        return True

    @kodion.RegisterProviderPath('^/sign/(?P<mode>.*)/$')
    def _on_sign(self, context, re_match):
        mode = re_match.group('mode')
        yt_login.process(mode, self, context, re_match, needs_tv_login=False)
        return True

    def on_search(self, search_text, context, re_match):
        result = []

        page_token = context.get_param('page_token', '')
        search_type = context.get_param('search_type', 'channel')

        json_data = context.get_function_cache().get(FunctionCache.ONE_MINUTE * 10, self.get_client(context).search,
                                                     q=search_text, search_type=search_type, page_token=page_token)
        if not v3.handle_error(self, context, json_data):
            return False
        result.extend(v3.response_to_items(self, context, json_data))
        return result

    @kodion.RegisterProviderPath('^/collection/(?P<collection>.+)/$')
    def on_collection(self, context, re_match):
        result = []

        collection = re_match.group('collection')
        channel_ids = self.COLLECTION_DUMMY[collection]

        last_100_item = DirectoryItem('[B]Last 100 videos[/B]', context.create_uri(['channels', '|'.join(channel_ids)]))
        result.append(last_100_item)

        channel_id_dict = {}
        for channel_id in channel_ids:
            channel_item = DirectoryItem(channel_id, context.create_uri(['channel', channel_id]))
            result.append(channel_item)

            channel_id_dict[channel_id] = channel_item
            pass

        channel_items_dict = {}
        update_channel_infos(self, context, channel_id_dict, channel_items_dict=channel_items_dict)
        update_fanarts(self, context, channel_items_dict)

        return result

    @kodion.RegisterProviderPath('^/collections/$')
    def on_collections(self, context, re_match):
        result = []

        for key in self.COLLECTION_DUMMY:
            collection = self.COLLECTION_DUMMY[key]
            collection_item = DirectoryItem(key, context.create_uri(['collection', key]))
            result.append(collection_item)
            pass

        return result

    def on_root(self, context, re_match):
        self.get_client(context)
        resource_manager = self.get_resource_manager(context)

        result = []

        # collections
        collections_item = DirectoryItem('Collections', context.create_uri(['collections']))
        result.append(collections_item)

        settings = context.get_settings()

        # sign in
        if not self.is_logged_in() and settings.get_bool('youtube.folder.sign.in.show', True):
            sign_in_item = DirectoryItem('[B]%s[/B]' % context.localize(self.LOCAL_MAP['youtube.sign.in']),
                                         context.create_uri(['sign', 'in']),
                                         image=context.create_resource_path('media', 'sign_in.png'))
            sign_in_item.set_fanart(self.get_fanart(context))
            result.append(sign_in_item)
            pass

        # search
        search_item = kodion.items.SearchItem(context, image=context.create_resource_path('media', 'search.png'),
                                              fanart=self.get_fanart(context))
        result.append(search_item)

        # subscriptions
        if self.is_logged_in():
            playlists = resource_manager.get_related_playlists(channel_id='mine')

            # watch later
            if 'watchLater' in playlists and settings.get_bool('youtube.folder.watch_later.show', True):
                watch_later_item = DirectoryItem(context.localize(self.LOCAL_MAP['youtube.watch_later']),
                                                 context.create_uri(
                                                     ['channel', 'mine', 'playlist', playlists['watchLater']]),
                                                 context.create_resource_path('media', 'watch_later.png'))
                watch_later_item.set_fanart(self.get_fanart(context))
                context_menu = []
                yt_context_menu.append_play_all_from_playlist(context_menu, self, context, playlists['watchLater'])
                watch_later_item.set_context_menu(context_menu)
                result.append(watch_later_item)
                pass

            # subscriptions
            if settings.get_bool('youtube.folder.subscriptions.show', True):
                subscriptions_item = DirectoryItem(context.localize(self.LOCAL_MAP['youtube.subscriptions']),
                                                   context.create_uri(['subscriptions', 'list']),
                                                   image=context.create_resource_path('media', 'channels.png'))
                subscriptions_item.set_fanart(self.get_fanart(context))
                result.append(subscriptions_item)
                pass
            pass

        # sign out
        if self.is_logged_in() and settings.get_bool('youtube.folder.sign.out.show', True):
            sign_out_item = DirectoryItem(context.localize(self.LOCAL_MAP['youtube.sign.out']),
                                          context.create_uri(['sign', 'out']),
                                          image=context.create_resource_path('media', 'sign_out.png'))
            sign_out_item.set_fanart(self.get_fanart(context))
            result.append(sign_out_item)
            pass

        return result

    def set_content_type(self, context, content_type):
        if content_type == kodion.constants.content_type.EPISODES:
            context.set_content_type(content_type)
            context.add_sort_method(kodion.constants.sort_method.UNSORTED,
                                    kodion.constants.sort_method.VIDEO_RUNTIME,
                                    kodion.constants.sort_method.VIDEO_TITLE,
                                    kodion.constants.sort_method.VIDEO_YEAR)
            pass
        pass

    def handle_exception(self, context, exception_to_handle):
        if isinstance(exception_to_handle, LoginException):
            context.get_access_manager().update_access_token('')
            context.get_ui().show_notification('Login Failed')
            context.get_ui().open_settings()
            return False

        return True

    pass